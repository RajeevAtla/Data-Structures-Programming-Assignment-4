package prereqchecker;

public class Node {
	String data;
	Node next;

	public Node(String data) {
		this.data = data;
	}

	public String getData() {
		return data;
	}
}